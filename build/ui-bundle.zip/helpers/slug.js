'use strict'

module.exports = (value) => value.trim().toLowerCase().replace(/\s/g, '-')
